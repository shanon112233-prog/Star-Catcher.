# Star Catcher — HTML5 Demo

เดโมเกมเก็บดาวแบบรอบสั้น 30 วินาที สร้างด้วย HTML, CSS, JavaScript และ Canvas โดยไม่ใช้ไลบรารีหรือไฟล์จากภายนอก

## โครงสร้างไฟล์

```text
playables-demo-starcatcher/
├── index.html   # โครงหน้าและ HUD
├── style.css    # รูปแบบ responsive
├── game.js      # วงจรเกม อินพุต คะแนน เวลา และชีวิต
└── README.md    # วิธีเปิดและหมายเหตุ
```

## วิธีเปิดเล่น

1. แตก ZIP ทั้งชุดไปไว้ในโฟลเดอร์เดียวกัน
2. เปิด `index.html` ในเบราว์เซอร์สมัยใหม่
3. กด **เริ่มเล่น**
4. แตะ/คลิกดาวที่ตกลงมาเพื่อเก็บ; บนคอมพิวเตอร์กด **Space** เพื่อเก็บดาวที่ใกล้กลางจอที่สุด
5. ถ้าปล่อยดาวหลุดจอครบ 3 ดวง หรือครบ 30 วินาที รอบจะจบ กดเล่นอีกครั้งเพื่อเริ่มใหม่

หากต้องการใช้ local server แทนการเปิดไฟล์โดยตรง ให้เปิด terminal ในโฟลเดอร์นี้แล้วรัน:

```bash
python3 -m http.server 8000
```

จากนั้นเปิด `http://localhost:8000` ในเบราว์เซอร์

## โครงสร้างระบบ

- สถานะหลัก: `ready` → `playing` → `over`
- `requestAnimationFrame`: วาดภาพและอัปเดตดาว/เวลาใน game loop
- Pointer Events: ใช้อินพุตเดียวกันสำหรับการแตะและคลิก
- Keyboard: Space เก็บดาวที่ใกล้กลางพื้นที่เล่นที่สุด
- Canvas: วาดพื้นหลังและดาวด้วยโค้ด จึงไม่มี asset ภายนอก
- HUD และหน้าจอเริ่ม/จบ: HTML semantic elements แยกจาก Canvas

## การเชื่อม YouTube Playables SDK

โหลด SDK ใน `index.html` ก่อน `game.js` (`https://www.youtube.com/game_api/v1`) และเรียกผ่าน wrapper ใน `game.js` ซึ่งข้ามไปเงียบๆ เมื่อไม่มี `ytgame` จึงยังเปิดเล่นในเครื่องได้ตามปกติ

| ข้อกำหนด | การทำงานในเกม |
|---|---|
| `firstFrameReady()` | เรียกหลังวาดเฟรมแรก |
| `gameReady()` | เรียกครั้งเดียว หลังเฟรมแรกและโหลดเซฟเสร็จ (หน้าเมนูกดเล่นได้แล้ว) |
| `loadData()` / `saveData()` | เซฟ JSON `{v, best}`; รอ `loadData` ก่อน `saveData`; ข้อมูลว่าง/เสียหาย/เวอร์ชันเก่าไม่ทำให้เกม error |
| `engagement.sendScore()` | ส่งสถิติสูงสุดตอนจบรอบ หลังบันทึกเซฟ เพื่อให้ best ที่ส่งตรงกับในเซฟ |
| `system.onPause/onResume` | หยุดเวลา/ดาว/อินพุตทั้งหมด และเซฟตอน pause; ไม่ใช้ Page Visibility API |
| `isAudioEnabled` / `onAudioEnabledChange` | เก็บสถานะ `audioEnabled` ไว้ (ตอนนี้เกมยังไม่มีเสียง) หากเพิ่มเสียงต้องเคารพค่านี้ |

### ก่อนส่งจริง
- ทดสอบด้วย Playables Test Suite / ในสภาพแวดล้อมจริงของ YouTube — ชุดนี้ทดสอบแค่ด้วย mock SDK ในเบราว์เซอร์
- ตรวจข้อกำหนด certification ล่าสุด (Accessibility, Design, i18n, Privacy, Stability ฯลฯ) ที่ยังไม่ได้ตรวจในรอบนี้ เช่น ขนาดไฟล์และการเรียกเครือข่าย
- ไม่ได้ยืนยันว่าจะผ่านการรับรอง
