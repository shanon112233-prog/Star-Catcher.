(() => {
  "use strict";

  const ROUND_SECONDS = 30;
  const MAX_LIVES = 3;
  // ---------- YouTube Playables SDK wrapper ----------
  // ทุกการเรียกผ่าน wrapper นี้ ถ้า SDK ไม่อยู่ (เปิดไฟล์ในเครื่อง) เกมจะข้ามไปเฉยๆ
  const SAVE_VERSION = 1;
  const sdk = (typeof ytgame !== "undefined" && ytgame) ? ytgame : null;
  let saveLoaded = false; // ต้อง loadData เสร็จก่อนจึง saveData ได้
  let bestScore = 0;
  let paused = false;
  let audioEnabled = true; // เกมนี้ยังไม่มีเสียง เก็บค่าไว้สำหรับตอนเพิ่มเสียง

  function sdkCall(fn) {
    try { return fn(sdk); } catch (error) {
      try { sdk && sdk.health && sdk.health.logWarning(); } catch (_) { /* ignore */ }
      return undefined;
    }
  }

  function parseSave(raw) {
    // รองรับข้อมูลเก่า/ว่าง/เสียหาย โดยไม่ throw
    try {
      const data = raw ? JSON.parse(raw) : null;
      const best = data && Number.isFinite(data.best) ? Math.max(0, Math.floor(data.best)) : 0;
      return { best };
    } catch (_) { return { best: 0 }; }
  }

  function saveProgress() {
    if (!sdk || !saveLoaded) return;
    sdkCall((s) => s.game.saveData(JSON.stringify({ v: SAVE_VERSION, best: bestScore })))?.catch?.(() => {});
  }

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");
  const overlay = document.getElementById("overlay");
  const playButton = document.getElementById("playButton");
  const overlayEyebrow = document.getElementById("overlayEyebrow");
  const overlayTitle = document.getElementById("overlayTitle");
  const overlayText = document.getElementById("overlayText");
  const scoreElement = document.getElementById("score");
  const timeElement = document.getElementById("time");
  const livesElement = document.getElementById("lives");

  let width = 0;
  let height = 0;
  let pixelRatio = 1;
  let state = "ready"; // ready | playing | over
  let score = 0;
  let lives = MAX_LIVES;
  let secondsLeft = ROUND_SECONDS;
  let spawnIn = 0.4;
  let stars = [];
  let lastFrame = 0;
  let lastDisplayedSecond = ROUND_SECONDS;
  let nextStarId = 0;
  let firstFrameSent = false;

  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    width = rect.width;
    height = rect.height;
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    draw();
  }

  function updateHud(force = false) {
    scoreElement.textContent = String(score);
    const shownSecond = Math.max(0, Math.ceil(secondsLeft));
    if (force || shownSecond !== lastDisplayedSecond) {
      timeElement.textContent = String(shownSecond);
      lastDisplayedSecond = shownSecond;
    }
    livesElement.textContent = `${"♥ ".repeat(lives)}${"♡ ".repeat(MAX_LIVES - lives)}`.trim();
    livesElement.setAttribute("aria-label", `${lives} ชีวิต`);
  }

  function startGame() {
    score = 0;
    lives = MAX_LIVES;
    secondsLeft = ROUND_SECONDS;
    lastDisplayedSecond = ROUND_SECONDS;
    spawnIn = 0.35;
    stars = [];
    state = "playing";
    overlay.hidden = true;
    updateHud(true);
    canvas.focus({ preventScroll: true });
    draw();
  }

  function finishGame(reason) {
    if (state !== "playing") return;
    state = "over";
    overlay.hidden = false;
    overlayEyebrow.textContent = reason === "lives" ? "ดาวหลุดจอครบแล้ว" : "หมดเวลาแล้ว";
    if (score > bestScore) {
      bestScore = score;
      saveProgress(); // บันทึกก่อนส่งคะแนน เพื่อให้ best ใน save ตรงกับที่ส่งเสมอ
    }
    if (sdk && bestScore > 0) {
      // ส่งคะแนนสูงสุดที่ตรงกับ save (ข้อกำหนด: best score ที่ส่งต้องเท่ากับใน save)
      sdkCall((s) => s.engagement.sendScore({ value: bestScore }))?.catch?.(() => {});
    }
    overlayTitle.textContent = `คุณเก็บได้ ${score} ดาว`;
    overlayText.textContent = score === 1
      ? "เก็บได้ 1 ดวง ลองเล่นอีกครั้งเพื่อทำคะแนนให้ดีกว่าเดิม"
      : `เก็บได้ ${score} ดวง ลองอีกครั้งเพื่อทำคะแนนให้ดีกว่าเดิม`;
    overlayText.textContent += ` (สถิติสูงสุด ${bestScore})`;
    playButton.textContent = "เล่นอีกครั้ง";
    updateHud(true);
  }

  function spawnStar() {
    const radius = 13 + Math.random() * 8;
    const margin = radius + 10;
    stars.push({
      id: nextStarId++,
      x: margin + Math.random() * Math.max(1, width - margin * 2),
      y: -radius - 3,
      radius,
      speed: 82 + Math.random() * 83,
      drift: (Math.random() - 0.5) * 24,
      phase: Math.random() * Math.PI * 2,
      rotation: Math.random() * Math.PI
    });
  }

  function collectStar(index) {
    if (state !== "playing" || index < 0 || index >= stars.length) return;
    stars.splice(index, 1);
    score += 1;
    updateHud();
  }

  function collectNearestStar() {
    if (!stars.length || state !== "playing") return;
    const centerX = width / 2;
    const centerY = height / 2;
    let nearestIndex = 0;
    let nearestDistance = Infinity;
    stars.forEach((star, index) => {
      const distance = Math.hypot(star.x - centerX, star.y - centerY);
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestIndex = index;
      }
    });
    collectStar(nearestIndex);
  }

  function onPointerDown(event) {
    if (state !== "playing" || paused) return;
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    let hitIndex = -1;
    let hitDistance = Infinity;

    stars.forEach((star, index) => {
      const distance = Math.hypot(star.x - x, star.y - y);
      const hitRadius = star.radius + 12;
      if (distance <= hitRadius && distance < hitDistance) {
        hitIndex = index;
        hitDistance = distance;
      }
    });
    if (hitIndex !== -1) collectStar(hitIndex);
  }

  function drawStar(x, y, outerRadius, rotation, alpha = 1) {
    const innerRadius = outerRadius * 0.46;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.globalAlpha = alpha;
    ctx.shadowColor = "rgba(255, 216, 105, 0.8)";
    ctx.shadowBlur = 18;
    ctx.beginPath();
    for (let point = 0; point < 10; point += 1) {
      const radius = point % 2 === 0 ? outerRadius : innerRadius;
      const angle = -Math.PI / 2 + (point * Math.PI) / 5;
      const px = Math.cos(angle) * radius;
      const py = Math.sin(angle) * radius;
      if (point === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    const gradient = ctx.createLinearGradient(-outerRadius, -outerRadius, outerRadius, outerRadius);
    gradient.addColorStop(0, "#fff5b6");
    gradient.addColorStop(1, "#ffc45f");
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.restore();
  }

  function draw() {
    if (!width || !height) return;
    const background = ctx.createLinearGradient(0, 0, 0, height);
    background.addColorStop(0, "#172044");
    background.addColorStop(1, "#10172f");
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, width, height);

    // จุดแสงตกแต่งแบบ deterministic เพื่อไม่สร้าง asset หรือ dependency เพิ่ม
    for (let i = 0; i < 34; i += 1) {
      const x = ((i * 97 + 31) % 997) / 997 * width;
      const y = ((i * 173 + 67) % 991) / 991 * height;
      const radius = i % 7 === 0 ? 1.7 : 1;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fillStyle = i % 4 === 0 ? "rgba(255, 226, 157, .42)" : "rgba(191, 207, 255, .27)";
      ctx.fill();
    }

    // เส้นบอกขอบล่างของพื้นที่เล่น
    ctx.fillStyle = "rgba(108, 129, 202, .12)";
    ctx.fillRect(0, height - 2, width, 2);

    stars.forEach((star) => {
      const pulse = Math.sin(star.phase) * 0.08;
      drawStar(star.x, star.y, star.radius * (1 + pulse), star.rotation, 1);
    });
  }

  function update(deltaSeconds) {
    if (state !== "playing") return;
    secondsLeft = Math.max(0, secondsLeft - deltaSeconds);
    updateHud();

    spawnIn -= deltaSeconds;
    if (spawnIn <= 0 && stars.length < 10) {
      spawnStar();
      spawnIn = Math.max(0.32, 0.72 - score * 0.006) + Math.random() * 0.2;
    }

    for (const star of stars) {
      star.y += star.speed * deltaSeconds;
      star.x += Math.sin(star.phase) * star.drift * deltaSeconds;
      star.phase += deltaSeconds * 3.2;
      star.rotation += deltaSeconds * 0.45;
      star.x = Math.max(star.radius, Math.min(width - star.radius, star.x));
    }

    const remainingStars = [];
    for (const star of stars) {
      if (star.y - star.radius > height) {
        lives -= 1;
        updateHud(true);
        if (lives <= 0) {
          stars = [];
          finishGame("lives");
          return;
        }
      } else {
        remainingStars.push(star);
      }
    }
    stars = remainingStars;

    if (secondsLeft <= 0) finishGame("time");
  }

  function frame(timestamp) {
    const deltaSeconds = lastFrame === 0 ? 0 : Math.min((timestamp - lastFrame) / 1000, 0.05);
    lastFrame = timestamp;
    if (!paused) update(deltaSeconds); // หยุดทุกอย่างระหว่าง onPause
    draw();
    if (!firstFrameSent) { firstFrameSent = true; sdkCall((s) => s.game.firstFrameReady()); markReady(); }
    window.requestAnimationFrame(frame);
  }

  playButton.addEventListener("click", startGame);
  canvas.addEventListener("pointerdown", onPointerDown);
  window.addEventListener("keydown", (event) => {
    if (event.code === "Space" && state === "playing" && !paused) {
      event.preventDefault();
      collectNearestStar();
    }
  });
  window.addEventListener("resize", resizeCanvas, { passive: true });
  if ("ResizeObserver" in window) {
    new ResizeObserver(resizeCanvas).observe(canvas);
  }

  updateHud(true);
  resizeCanvas();
  window.requestAnimationFrame(frame);

  // ---------- SDK lifecycle ----------
  if (sdk) {
    sdkCall((s) => s.system.onPause(() => { paused = true; saveProgress(); }));
    sdkCall((s) => s.system.onResume(() => { paused = false; lastFrame = 0; }));
    audioEnabled = sdkCall((s) => s.system.isAudioEnabled()) !== false;
    sdkCall((s) => s.system.onAudioEnabledChange((enabled) => { audioEnabled = enabled; }));
  }

  // โหลดเซฟให้เสร็จก่อน แล้วค่อยบอก gameReady (หน้าเมนูเริ่มเล่นแสดงอยู่และกดได้แล้ว)
  // gameReady ต้องถูกเรียกหลัง firstFrameReady และหลังโหลดเซฟเสร็จ (เรียกซ้ำได้ ส่งครั้งเดียว)
  let readySent = false;
  function markReady() {
    if (!sdk || readySent || !firstFrameSent || !saveLoaded) return;
    readySent = true;
    sdkCall((s) => s.game.gameReady());
  }
  if (sdk) {
    const loading = sdkCall((s) => s.game.loadData());
    Promise.resolve(loading)
      .then((raw) => { bestScore = parseSave(raw).best; })
      .catch(() => { bestScore = 0; })
      .finally(() => {
        saveLoaded = true;
        if (bestScore > 0 && state === "ready") overlayText.textContent += ` (สถิติสูงสุด ${bestScore})`;
        markReady();
      });
  }
})();
